# 红蜻蜓 - Mac to iPhone

Mac 通过 USB 连接 iPhone 的路线播放与定位测试工具。**内置樱花园周边两条近似路线：圣馨家园、元大都公园（东段）**。

## 下载并打开

**[直接下载 Mac 应用（Apple Silicon）](https://github.com/fanyqhidbi/hongqingting-mac-to-iphone/releases/download/v1.2.0/HongQingTing-Mac-to-iPhone-v1.2.0-arm64.zip)** · [版本与全部下载](https://github.com/fanyqhidbi/hongqingting-mac-to-iphone/releases/latest)

下载 `HongQingTing-Mac-to-iPhone-v1.2.0-arm64.zip`，解压后把 **红蜻蜓 Mac to iPhone.app** 拖到“应用程序”，双击打开。下载的是完整 Mac 应用，包含 Python 和所需依赖，无须另装 Python、Conda 或通过终端启动。

当前下载包适用于 **Apple Silicon Mac（M1/M2/M3/M4 等），macOS 14 及以上**。Intel Mac 需要在 Intel 机器上从源码构建。

本版本没有 Apple Developer ID 公证。首次打开可能出现 macOS 的开发者验证提示，请根据系统提示在“系统设置 → 隐私与安全性”确认打开；不要关闭系统整体安全保护。

![应用界面](docs/app-preview.png)

## 内置两条路线

| 路线 | 距离 | 点位数 | 单次时长 |
| --- | --- | --- | --- |
| 圣馨家园 | 约 2.00 公里 | 361 | 18 分钟 |
| 元大都公园（东段） | 约 2.10 公里 | **500** | 18 分钟 |

“樱花园周边”是本路线包的说明，实际起终点请以路线坐标为准。两条路线根据地图截图及 OpenStreetMap 道路数据近似制作，不是 Keep 原始 GPS 轨迹或真实运动记录。坐标使用 WGS84。

![元大都公园东段路线](docs/yuandadu_east_2_1km_18min.png)

![圣馨家园路线](docs/shengxin_2km_18min.png)

## 连接 iPhone

1. 用支持数据传输的 USB 线连接 Mac 和 iPhone，解锁手机，在手机上确认“信任这台电脑”。
2. 在 iPhone 的“设置 → 隐私与安全性 → 开发者模式”手动开启，按手机提示重启并确认。
3. 首次使用的手机需要准备兼容的开发者镜像。可用与手机系统兼容的 Xcode，在 **Window → Devices and Simulators** 中选中手机，等待设备准备完成。
4. 打开本应用，点击“刷新设备”，选中一台 iPhone，再点“连接选中”。
5. 进入“路线播放”，选择路线，**循环圈数选 1**，点击“开始运行”。单次约 18 分钟；软件不会自动在手机中的其他 App 开始记录。

Mac 版一次控制一台 iPhone，使用进程内 USB 连接，不需要管理员 tunneld 服务，也不依赖 Proxyman。

如果开发者模式选项没有出现，可尝试应用设置中的“显示开发者选项”，然后仍在手机上手动开启。若显示 `com.apple.instruments.dtservicehub` 不可用，请检查开发者模式和开发者镜像。手机重启或更换后，退出应用并重新连接。

## 功能

- USB 设备发现与连接。
- JSON / GPX 路线导入、路线播放与循环。
- 内置路线按总时长调度点位，避免点位数量变化导致时长改变。
- 配速跑、随机游走、矩形校准与配置预设。
- 停止或退出时清理定位与连接。

本工具是 GeoPilot 的独立 macOS 适配版本，与飞翔的红蜻蜓、学校或 Keep 官方无隶属关系，也不保证第三方 App 会接受模拟定位。

## 数据位置

打包应用首次打开会把内置路线和预设复制到 `~/Library/Application Support/HongQingTing/`，之后的自定义配置保存在这里。可移动、重命名应用，不依赖桌面路径；升级不会覆盖已有用户文件。运行日志在同目录的 `runtime.log`。

## 源码运行与构建

```sh
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-mac.txt
python app.py
```

构建完整 `.app`：

```sh
python -m pip install pyinstaller==6.22.3
python scripts/collect_licenses.py
python -m PyInstaller hongqingting.spec --clean --noconfirm
```

输出：`dist/红蜻蜓 Mac to iPhone.app`。在目标架构的 Mac 上构建。完整依赖版本记录在 `requirements-mac.lock`。

离线验证：

```sh
python -m unittest discover -s tests -v
QT_QPA_PLATFORM=offscreen GEOPILOT_DATA_DIR=/tmp/hongqingting-test python app.py --self-test
```

## 来源

基于 [GeoPilot / College-Running-Assistant-Only-For-iPhone](https://github.com/andynubia12-byte/College-Running-Assistant-Only-For-iPhone) 改编；保留[上游说明](docs/UPSTREAM_README.md)。路线地图数据 © OpenStreetMap contributors，遵循 [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/)。其他许可与第三方说明见 [NOTICE.md](NOTICE.md)。
