# 项目来源与第三方声明

此项目是 GeoPilot 的 macOS 适配与应用打包版本，项目展示名为“红蜻蜓 - Mac to iPhone”。它是独立工具，与“飞翔的红蜻蜓”官方 App、学校或 Keep 没有隶属关系。

上游项目：[andynubia12-byte/College-Running-Assistant-Only-For-iPhone](https://github.com/andynubia12-byte/College-Running-Assistant-Only-For-iPhone)。原作者说明保留在 `docs/UPSTREAM_README.md`。上游源码的著作权归原权利人；本仓库未将上游代码重新声明为 MIT 或其他宽松许可证。

路线为依据用户提供的地图截图和公开地图道路坐标制作的近似路线，包含公开公园与街道，不包含用户的真实运动记录。地图几何数据：© OpenStreetMap contributors，遵循 [Open Database License 1.0](https://opendatacommons.org/licenses/odbl/1-0/)。[OpenStreetMap 版权说明](https://www.openstreetmap.org/copyright)。

PySide6/Qt、Python、pymobiledevice3 及其依赖使用各自许可证。应用包保留第三方许可证文本，见 `THIRD_PARTY_LICENSES/`。Qt 使用动态库链接；源码与构建配置一并提供。
