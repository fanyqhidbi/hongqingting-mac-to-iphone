"""macOS USB discovery and a single closeable, root-free iPhone connection."""
import asyncio
from dataclasses import dataclass

from pymobiledevice3.lockdown import create_using_usbmux
from pymobiledevice3.usbmux import list_devices


@dataclass
class DeviceEntry:
    peer_info: dict


_provider = None
_tunnel = None
_serial = None


async def discover_devices():
    devices = []
    for mux in await list_devices():
        if not mux.is_usb:
            continue
        properties = {
            'UniqueDeviceID': mux.serial, 'ProductType': 'iPhone',
            'OSVersion': '待连接', 'DeviceName': 'USB 设备（请解锁并信任电脑）',
        }
        lockdown = None
        try:
            lockdown = await asyncio.wait_for(
                create_using_usbmux(serial=mux.serial, autopair=False), timeout=5)
            values = lockdown.all_values
            properties.update({
                'ProductType': values.get('ProductType', 'iPhone'),
                'OSVersion': values.get('ProductVersion', '未知'),
                'DeviceName': values.get('DeviceName', 'iPhone'),
            })
        except Exception:
            pass  # An unpaired device remains visible; pairing is left to the user.
        finally:
            if lockdown is not None:
                await lockdown.close()
        devices.append(DeviceEntry({'Properties': properties}))
    return devices


async def close_devices():
    global _provider, _tunnel, _serial
    provider, tunnel = _provider, _tunnel
    _provider = _tunnel = _serial = None
    if tunnel is not None:
        await tunnel.aclose()
    elif provider is not None:
        await provider.close()


async def connect_device(serial=None):
    global _provider, _tunnel, _serial
    if _provider is not None and _serial == serial:
        return _provider
    await close_devices()
    lockdown = None
    tunnel = None
    try:
        lockdown = await asyncio.wait_for(
            create_using_usbmux(serial=serial, autopair=False), timeout=15)
        values = lockdown.all_values
        version = str(values.get('ProductVersion', '0'))
        properties = {
            'UniqueDeviceID': lockdown.udid,
            'ProductType': values.get('ProductType', 'iPhone'),
            'OSVersion': version, 'DeviceName': values.get('DeviceName', 'iPhone'),
        }
        if int(version.split('.')[0]) >= 17:
            # The upstream userspace stack supports one active device per process.
            from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
            await lockdown.close()
            lockdown = None
            tunnel = UserspaceRsdTunnel(serial=serial, autopair=False)
            provider = await asyncio.wait_for(tunnel.aopen(), timeout=30)
        else:
            provider, lockdown = lockdown, None
        provider._geopilot_info = properties
        _provider, _tunnel, _serial = provider, tunnel, serial
        return provider
    except BaseException:
        if tunnel is not None:
            await tunnel.aclose()
        raise
    finally:
        if lockdown is not None:
            await lockdown.close()
