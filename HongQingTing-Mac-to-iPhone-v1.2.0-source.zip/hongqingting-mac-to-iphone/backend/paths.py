"""Separate bundled defaults from writable user data."""
import os
import shutil
import sys
from pathlib import Path

RESOURCE_DIR = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))
if os.environ.get('GEOPILOT_DATA_DIR'):
    DATA_DIR = Path(os.environ['GEOPILOT_DATA_DIR']).expanduser().resolve()
elif getattr(sys, 'frozen', False):
    DATA_DIR = Path.home() / 'Library/Application Support/HongQingTing'
else:
    DATA_DIR = Path(__file__).resolve().parent.parent


def initialize_data():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for directory in ('routes', 'configs'):
        target = DATA_DIR / directory
        target.mkdir(exist_ok=True)
        for source in (RESOURCE_DIR / directory).glob('*.json'):
            destination = target / source.name
            if not destination.exists():
                shutil.copy2(source, destination)
    source = RESOURCE_DIR / 'config.json'
    destination = DATA_DIR / 'config.json'
    if not destination.exists() and source.exists():
        shutil.copy2(source, destination)
