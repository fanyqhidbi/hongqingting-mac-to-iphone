"""Preserve installed dependency license texts in the application distribution."""
import importlib.metadata
import re
import shutil
import sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
target = root / 'THIRD_PARTY_LICENSES'
target.mkdir(exist_ok=True)
summary = ['# Third-party components', '', 'License texts copied from the installed build dependencies.', '']
for distribution in sorted(importlib.metadata.distributions(), key=lambda d: d.metadata['Name'].lower()):
    name = distribution.metadata['Name']
    if name.lower() in {'pip','setuptools','pyinstaller','pyinstaller-hooks-contrib','altgraph','macholib'}:
        continue
    safe = re.sub(r'[^A-Za-z0-9._-]', '_', name)
    found = []
    for file in distribution.files or []:
        if re.search(r'(^|/)(licenses?([./_-]|$)|copying|copyright|notice)',str(file),re.I):
            source = Path(distribution.locate_file(file))
            if source.is_file() and source.stat().st_size < 2_000_000:
                destination = target / safe / str(file).replace('../','').replace('..\\','')
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
                found.append(str(destination.relative_to(target)))
    summary.append(f'- {name} {distribution.version}: '+(', '.join(found) or 'See package metadata and upstream project.'))
for source in [Path(sys.base_prefix)/'LICENSE.txt',Path(sys.base_prefix)/'LICENSE_PYTHON.txt']:
    if source.is_file():
        shutil.copy2(source,target/('Python-'+source.name))
(target/'README.md').write_text('\n'.join(summary)+'\n')
print('THIRD_PARTY_LICENSES_COLLECTED')
