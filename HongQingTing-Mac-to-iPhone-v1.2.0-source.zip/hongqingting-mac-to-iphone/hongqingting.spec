# Build on the target Mac architecture with Python 3.11.
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules, copy_metadata

root = Path(SPECPATH)
datas = [(str(root/'routes'),'routes'), (str(root/'configs'),'configs'),
         (str(root/'config.json'),'.'), (str(root/'NOTICE.md'),'.'),
         (str(root/'THIRD_PARTY_LICENSES'),'THIRD_PARTY_LICENSES')]
datas += collect_data_files('pymobiledevice3')
datas += copy_metadata('pymobiledevice3')
hidden = collect_submodules('pmd_pytcp')
hidden += ['pymobiledevice3.osu.posix_util', 'pymobiledevice3.osu.os_utils',
           'pymobiledevice3.remote.userspace_tunnel',
           'pymobiledevice3.services.amfi',
           'pymobiledevice3.services.dvt.instruments.location_simulation',
           'PySide6.QtCore','PySide6.QtGui','PySide6.QtWidgets']
a = Analysis([str(root/'app.py')], pathex=[str(root)], binaries=[], datas=datas,
             hiddenimports=hidden, hookspath=[], runtime_hooks=[],
             excludes=['tkinter','matplotlib','numpy','pandas','scipy','PyQt5','PyQt6',
                       'PySide2','IPython','pytest','notebook','jupyter','pynput'],
             noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz,a.scripts,[],exclude_binaries=True,name='HongQingTing',
          debug=False,bootloader_ignore_signals=False,strip=False,upx=False,
          console=False,argv_emulation=False,target_arch=None,
          codesign_identity=None,entitlements_file=None)
coll = COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='HongQingTing')
app = BUNDLE(coll,name='红蜻蜓 Mac to iPhone.app',icon=None,
             bundle_identifier='io.github.hongqingting.mac-to-iphone',
             info_plist={'CFBundleShortVersionString':'1.2.0','CFBundleVersion':'1.2.0',
                         'CFBundleDisplayName':'红蜻蜓 Mac to iPhone',
                         'LSMinimumSystemVersion':'14.0','NSHighResolutionCapable':True,
                         'LSMultipleInstancesProhibited':True})
