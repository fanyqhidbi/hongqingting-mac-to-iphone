# GeoPilot UI widgets
