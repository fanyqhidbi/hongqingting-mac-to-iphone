#!/usr/bin/env python3
"""GeoPilot PySide6 GUI entry point."""
import sys
import os
import asyncio
from pathlib import Path

# PyInstaller console=False compatibility
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")


def _run_tunneld_service():
    from tunneld_service import main as run_service
    run_service()


def main():
    from backend.paths import DATA_DIR, initialize_data
    initialize_data()
    if getattr(sys, 'frozen', False):
        log = open(DATA_DIR / 'runtime.log', 'a', encoding='utf-8', buffering=1)
        sys.stdout = sys.stderr = log
    # --tunneld: service mode (no GUI)
    if "--tunneld" in sys.argv:
        _run_tunneld_service()
        return

    import qasync
    from PySide6.QtWidgets import QApplication
    from PySide6.QtGui import QFont, QFontDatabase, QAction, QKeySequence
    from PySide6.QtCore import QTimer, QEvent

    from ui.main_window import MainWindow
    from ui.theme import STYLESHEET

    def _get_font_dir():
        if getattr(sys, 'frozen', False):
            return Path(sys._MEIPASS) / 'ui' / 'fonts'
        return Path(__file__).parent / 'ui' / 'fonts'

    def _load_fonts():
        if sys.platform == 'darwin':
            return  # Use macOS's installed PingFang rather than loading font copies.
        font_dir = _get_font_dir()
        for f in sorted(font_dir.glob('*.otf')):
            QFontDatabase.addApplicationFont(str(f))

    class GeoPilotApplication(QApplication):
        shutdown_requested = None

        def event(self, event):
            if event.type() == QEvent.Type.Quit and self.shutdown_requested is not None:
                # Keep Qt's event loop alive until device cleanup has completed.
                self.shutdown_requested()
                event.ignore()
                return True
            return super().event(event)

    self_test = '--self-test' in sys.argv
    app = GeoPilotApplication([arg for arg in sys.argv if arg != '--self-test'])
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName("红蜻蜓 · Mac to iPhone")
    app.setOrganizationName("HongQingTing")
    app.setStyle("Fusion")
    _load_fonts()
    app.setStyleSheet(STYLESHEET)
    app.setFont(QFont("PingFang SC", 12))

    async def run():
        window = MainWindow()
        app.shutdown_requested = window.close
        stop_event = asyncio.Event()
        window.closing.connect(stop_event.set)
        app.aboutToQuit.connect(stop_event.set)
        if sys.platform == 'darwin':
            quit_action = QAction('退出 GeoPilot', window)
            quit_action.setMenuRole(QAction.MenuRole.QuitRole)
            quit_action.setShortcut(QKeySequence.StandardKey.Quit)
            quit_action.triggered.connect(window.close)
            window.menuBar().addMenu('GeoPilot').addAction(quit_action)
        window.show()
        if sys.platform == 'darwin' and not self_test:
            def show_on_desktop():
                window.raise_()
                window.activateWindow()
                print(f'MAC_GUI_VISIBLE platform={app.platformName()} visible={window.isVisible()}', flush=True)
            QTimer.singleShot(0, show_on_desktop)
        if self_test:
            # Exercise the dependencies that must also work in the frozen build.
            from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
            from pymobiledevice3.services.dvt.instruments.location_simulation import LocationSimulation
            from pymobiledevice3.services.amfi import AmfiService
            from backend.routes import list_routes, load_route
            routes = list_routes()
            assert len(routes) >= 2
            route = load_route('yuandadu_east_2_1km_18min.json')
            assert len(route['coordinates']) == 500 and route['duration_seconds'] == 1080
            print('BUNDLED_ROUTES_AND_DEVICE_IMPORTS_OK', flush=True)
            if os.environ.get('GEOPILOT_SELF_TEST_NATIVE_QUIT') == '1':
                window.run_page._controller._task = asyncio.create_task(asyncio.sleep(100))
            def finish_test():
                image_path = os.environ.get('GEOPILOT_SELF_TEST_IMAGE')
                if image_path:
                    window.grab().save(image_path)
                print('MAC_GUI_SELF_TEST_OK', flush=True)
                if os.environ.get('GEOPILOT_SELF_TEST_NATIVE_QUIT') == '1':
                    app.quit()
                else:
                    window.close()
            QTimer.singleShot(350, finish_test)
        try:
            await stop_event.wait()
        finally:
            controller = window.run_page._controller
            controller.stop()
            if controller._task is not None:
                try:
                    await asyncio.wait_for(controller._task, timeout=5)
                except (asyncio.CancelledError, TimeoutError):
                    pass
            localizer = window.calibrate_page._localizer
            if localizer is not None:
                try:
                    await asyncio.wait_for(localizer.__aexit__(None, None, None), timeout=5)
                except Exception:
                    pass
            if sys.platform == 'darwin':
                from backend.mac_device import close_devices
                await asyncio.wait_for(close_devices(), timeout=5)
            app.shutdown_requested = None
            if self_test:
                print('MAC_GUI_CLEANUP_OK', flush=True)

    try:
        qasync.run(run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
