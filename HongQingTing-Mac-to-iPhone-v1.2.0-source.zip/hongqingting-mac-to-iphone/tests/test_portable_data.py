import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class PortableDataTests(unittest.TestCase):
    def test_first_launch_seeds_routes_and_preserves_existing_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            env = {**os.environ, 'GEOPILOT_DATA_DIR': temp, 'PYTHONPATH': str(ROOT)}
            code = "from backend.routes import list_routes; from backend.config import load_config; print(len(list_routes())); print(load_config()['loop_count'])"
            result = subprocess.run([sys.executable,'-c',code],cwd='/',env=env,capture_output=True,text=True,check=True)
            self.assertEqual(result.stdout.strip().splitlines(),['2','1'])
            config = Path(temp)/'config.json'
            saved = json.loads(config.read_text())
            saved['loop_count'] = 2
            config.write_text(json.dumps(saved))
            result = subprocess.run([sys.executable,'-c',code],cwd='/',env=env,capture_output=True,text=True,check=True)
            self.assertEqual(result.stdout.strip().splitlines(),['2','2'])

    def test_yuandadu_500_points_keep_eighteen_minute_schedule(self):
        import asyncio
        from unittest.mock import patch
        sys.path.insert(0,str(ROOT))
        from backend import modes
        route = json.loads((ROOT/'routes/yuandadu_east_2_1km_18min.json').read_text())
        clock = [0.0]
        times = []
        async def sleep(delay):
            clock[0] += delay
        async def play():
            with patch.object(modes.time,'monotonic',side_effect=lambda:clock[0]), patch.object(modes.asyncio,'sleep',side_effect=sleep):
                async for data, meta in modes.gen_route(route,{'loop_count':1,'jitter_meters':0},asyncio.Event()):
                    if data:
                        times.append(clock[0])
                        clock[0] += .4
        asyncio.run(play())
        self.assertEqual(len(times),500)
        self.assertAlmostEqual(times[-1],1080)


if __name__ == '__main__':
    unittest.main()
