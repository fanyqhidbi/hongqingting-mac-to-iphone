import asyncio
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend import modes

class TimedRouteTests(unittest.IsolatedAsyncioTestCase):
    async def test_distance_and_duration_do_not_drift_with_device_latency(self):
        route=json.loads((Path(__file__).resolve().parent.parent / 'routes/shengxin_2km_18min.json').read_text())
        clock=[0.0]
        async def sleep(delay):clock[0]+=delay
        times=[];last=None
        with patch.object(modes.time,'monotonic',side_effect=lambda:clock[0]), patch.object(modes.asyncio,'sleep',side_effect=sleep):
            async for data,meta in modes.gen_route(route,{'loop_count':1,'jitter_meters':0},asyncio.Event()):
                if data:
                    times.append(clock[0]);clock[0]+=.4
                if meta and meta.get('done'):last=meta
        self.assertEqual(len(times),361)
        self.assertAlmostEqual(times[0],0)
        self.assertAlmostEqual(times[-1],1080)
        self.assertAlmostEqual(last['elapsed'],1080.4)
        self.assertTrue(1990<last['total_dist']<2010)
        self.assertAlmostEqual(last['total_dist'],route['distance_m'],places=2)

    async def test_stopped_route_emits_no_location(self):
        stop=asyncio.Event();stop.set()
        route={'coordinates':[{'lat':40,'lng':116},{'lat':40.01,'lng':116}],'duration_seconds':1080}
        events=[event async for event in modes.gen_route(route,{},stop)]
        self.assertFalse(any(data for data,meta in events))
        self.assertEqual(events[-1][1]['tick'],0)

    async def test_invalid_duration_is_rejected(self):
        for duration in (0,-1,float('nan'),float('inf')):
            with self.subTest(duration=duration),self.assertRaises(ValueError):
                async for _ in modes.gen_route({'coordinates':[{},{}],'duration_seconds':duration},{},asyncio.Event()):pass

if __name__=='__main__':unittest.main()
