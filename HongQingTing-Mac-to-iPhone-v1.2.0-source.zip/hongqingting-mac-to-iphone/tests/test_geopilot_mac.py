import asyncio
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest
from unittest.mock import AsyncMock, Mock, patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from backend import mac_device
from backend.device import format_device_info
from ui.tunneld_manager import TunneldManager


def phone(version='26.0'):
    return SimpleNamespace(
        udid='TEST-DEVICE',
        all_values={'ProductVersion': version, 'ProductType': 'iPhone17,1',
                    'DeviceName': 'Test iPhone'},
        close=AsyncMock(),
    )


class DeviceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        mac_device._provider = mac_device._tunnel = mac_device._serial = None

    async def asyncTearDown(self):
        await mac_device.close_devices()

    async def test_usb_discovery_ignores_network_devices_and_does_not_pair(self):
        lockdown = phone()
        entries = [SimpleNamespace(serial='TEST-DEVICE', is_usb=True),
                   SimpleNamespace(serial='NETWORK-DEVICE', is_usb=False)]
        with patch.object(mac_device, 'list_devices', AsyncMock(return_value=entries)), \
             patch.object(mac_device, 'create_using_usbmux', AsyncMock(return_value=lockdown)) as create:
            result = await mac_device.discover_devices()
        self.assertEqual(len(result), 1)
        self.assertEqual(format_device_info(result[0])['name'], 'Test iPhone')
        create.assert_awaited_once_with(serial='TEST-DEVICE', autopair=False)
        lockdown.close.assert_awaited_once()

    async def test_unpaired_device_remains_visible(self):
        entries = [SimpleNamespace(serial='TEST-DEVICE', is_usb=True)]
        with patch.object(mac_device, 'list_devices', AsyncMock(return_value=entries)), \
             patch.object(mac_device, 'create_using_usbmux', AsyncMock(side_effect=RuntimeError('not paired'))):
            result = await mac_device.discover_devices()
        self.assertEqual(len(result), 1)
        self.assertIn('信任', format_device_info(result[0])['name'])

    async def test_modern_ios_uses_one_root_free_session_and_closes_it(self):
        lockdown, provider = phone(), SimpleNamespace()
        tunnel = SimpleNamespace(aopen=AsyncMock(return_value=provider), aclose=AsyncMock())
        with patch.object(mac_device, 'create_using_usbmux', AsyncMock(return_value=lockdown)), \
             patch('pymobiledevice3.remote.userspace_tunnel.UserspaceRsdTunnel', return_value=tunnel) as factory:
            result = await mac_device.connect_device('TEST-DEVICE')
            reused = await mac_device.connect_device('TEST-DEVICE')
        self.assertIs(result, provider)
        self.assertIs(reused, provider)
        factory.assert_called_once_with(serial='TEST-DEVICE', autopair=False)
        lockdown.close.assert_awaited_once()
        self.assertEqual(format_device_info(provider)['os_version'], '26.0')
        await mac_device.close_devices()
        tunnel.aclose.assert_awaited_once()

    async def test_failed_modern_connection_releases_session(self):
        lockdown = phone()
        tunnel = SimpleNamespace(aopen=AsyncMock(side_effect=RuntimeError('test failure')), aclose=AsyncMock())
        with patch.object(mac_device, 'create_using_usbmux', AsyncMock(return_value=lockdown)), \
             patch('pymobiledevice3.remote.userspace_tunnel.UserspaceRsdTunnel', return_value=tunnel):
            with self.assertRaisesRegex(RuntimeError, 'test failure'):
                await mac_device.connect_device('TEST-DEVICE')
        tunnel.aclose.assert_awaited_once()
        self.assertIsNone(mac_device._provider)

    async def test_older_ios_keeps_and_closes_usb_provider(self):
        lockdown = phone('16.7')
        with patch.object(mac_device, 'create_using_usbmux', AsyncMock(return_value=lockdown)):
            result = await mac_device.connect_device('TEST-DEVICE')
        self.assertIs(result, lockdown)
        lockdown.close.assert_not_awaited()
        await mac_device.close_devices()
        lockdown.close.assert_awaited_once()


class StartupTests(unittest.TestCase):
    def test_mac_does_not_launch_privileged_daemon(self):
        with patch('ui.tunneld_manager.subprocess.Popen') as process:
            self.assertTrue(TunneldManager.launch())
        process.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
